---
title: "Title/Reference"
start-date: YYYY-MM-DD
end-date: 
source: Zotero/Archival ref.
created: 2023-12-19 14:28
revised: 2023-12-19
---
# AGI Santa Fe 227 
Cartas y expedientes del Arzobispo de la ciudad de Santa Fé, vistos en el consejo. 
Años 1573-1631 

Notice - 
54. 1599-05-24 — La carta de d. Francisco de Sande, de 1599-05-24, que estaba en Santa Fe 226 se ha pasado a Santa Fe 17a, que corresponde \(1966-10-05\) 
78. 1603-05-26 — La carta del lic. Juan de Bolaños, de 1603-05-26, que estaba en Santa Fe 226, se ha pasado a Santa Fe 240, a que pertenece \(same date\) 
106. 1607-09-04 — La carta de Domingo de Eraso, de 1607-09-04, que estaba en Santa Fe 226, se ha pasado a Santa Fe 98, a que corresponde \(same date\) 
143. 1621-06-18 — La carta de la Audiencia, de 1621-06-18, que estaba en Santa Fe 226, se ha pasado a Santa Fe 20, a que pertenece \(same date\) 

# Contents - 

1. 1572-12-01 — Zapata requests payment for wages whilst bp of Cartagena 
2. 1573-03-31 - Zapata comunica llegada y situación – AGI SF 226, n.2 
3. 1573-08-20 - Zapata sobre asuntos eclesiásticos – AGI SF 226, n.3 
4. 1573-10-24 - Zapata sobre situación Cartagena – AGI SF 226, n.4 
5. 1575-03-08 - Instrucción Zapata a procuradores en la corte – AGI SF 226, n.5 
6. 1575-04-16 - Memorial Zapata – AGI SF 226, n.6-6a 
7. 1575-04-22 - Zapata sobre actuaciones – AGI SF 226, n.7 
8. 1575-09-20 - Zapata sobre R Patronazgo y frailes – AGI SF 226, n.8 
9. 1577-02-01 - Zapata on arrival of oidor Cortés de Mesa – AGI SF 226, n.9 
10. 1577-02-04 – Domingo de Uribe on behalf of Zapata to the king, `DONE` 
11. 1577-02-08 — Zapata to the king, shorter letter. `DONE` 