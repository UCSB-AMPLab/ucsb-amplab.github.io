---
author:
title:
start-date:
place:
source:
---

# 1594-1596 – Juan, Cacique de [[Fontibón]], vs indios de su cacicazgo – AGN CI 9 d 13

[[Don Juan, cacique Fontibón]]

~~453r~~

> En 22 de noviembre de 95 años por el

> Escribano Velázquez Juan de Pamaga

> Francisco Coas, natural de Fontibón, dice que viniendo a coger trigo me maltrató a mí y a Francisco Coaba mi hermano, el cacique don Juan y nos hizo malos tratamientos y rompió las mantas poniendo las manos en nosotros y lo mismo hizo a los demás capitanes a mis compañeros, lo cual no es justo se permita pues el cacique ha de hacer obedecer y respetar a los capitanes, para que todos entiendan en el regimiento del pueblo y vuelvan por el mismo cacique.

> Suplico a vuestra señoría mandé recibir información de lo que aquí digo y constando ser así, mande que el dicho cacique de aquí adelante entienda que ha de hacer sin agraviar a los capitanes ni a ningún indio, pues de hacerlo se sirve a su majestad y nosotros recibiremos mucho bien cual y merced con justicia y para ello etcétera.

> Otrosí. Que el dicho cacique me maltrató por amor de su mujer y esto no es justo se haga, pues el cacique nos ha de amparar y no quitarnos las mujeres.

> Suplico a vuestra señoría que sobre esto se reciba información.

> Francisco Coaba, indio.

~~453v~~

> Que den información de su querella y dada se traiga para proveer. Santa Fe 5 de octubre 1595.

> Tomás Velázquez [rubricado].

### Información

#### Francisco Apantiva
> 
> En la ciudad de Santafé a 6 días del mes de octubre de 1595 años el dicho Francisco Upaga para la dicha información presentó por testigo a un indio que por lengua de Juan de Murcia dijo llamarse Francisco Apantiba y que es natural de Fontibón y de la parte del capipapo? del cual mediante la dicha lengua siendo preguntado por el tenor della dijo que ella dijo ue este testigo conoce al dicho Fransico Coba y al dicho don Juan Cacique y lo que sabe es y vio es que estando [...] este mes este testigo y el dicho don Juan y los indios de Fobntibón en la estancia de los frailes de Santo Domingo de esta ciudad, el dicho don Juan fue para el dicho Francisco sin le dar ocasión y tener causa para ello y arremetio el dicho don Juan cacique para el dicho Francisco y lo echó en el suelo dándole de mojicones y coces ~~454r~~ y demás de esto vio este testigo como le dio el dicho don Juan al dicho Francisco con un palo en todo su cuerpo y le rompio la camiseta y un hermano del dicho Francsico llamado Francisco se llegó al dicho don Juan y le dijo que porque le daba al dicho su hermano sin le haber hecho cosa ninguna, y el dicho don Juan que menos manda a vos a hablar aquí y le dio con el palo en su cuerpo con que le habia dado al dicho su hermano y les hizo otros malos tratamientos que si el padre que allí estaba de Santo Domingo no llegara a los quitar los matara el dicho don Juan a los dichos Francisco y su hermano, y nunca este testigo vio que los dieran ocación al dicho don Juan más de que el dicho don Juan quiere mal al dicho Francisco porque anda con la mujer del dicho Francisco y en ella el dicho don Juan tiene un hijo y por esta ocación quiere mal al dicho Francisco y esto es la verdad y que sabe y vio por el juramento que hizo mediante la dicha lengua y no es pariente de ninguna de las partes ni le han dado oro ni otra cosa para que diga. Y según su aspecto pareciose ser de edad de 35 años y la dicha lengua dijo haber dicho e interpretado verdad en el que ha dicho el dicho indio y se le ha preguntado por el tenor ~~454v~~ de la dicha querella y así lo juró a Dios y a una cruz en forma de derecho ...

#### Diego Saxipa 

> [...] un indio que mediante la dicha lengua dijo llamarse Diego Sagipa y que es natural de Fontibón de la parte del capitán Gachetiva [...]
> [...] que estando este testigo y el dicjo Juan y el dicho Francisco y los indios de Fontibón en la estancia de los frayles dominicos cogiendo el trigo, vio este testigo como el dicho Juan cacique de Fontibón se fue para el dicho Francisco que le presenta por testigo sin que le diese ocasión alguna y le dio el dicho Juan al dicho Grancisco con un palo en todo su cuerpo y de mojicones echándole mano de los cabellos y dando con el en el suelo y alli le dio de coces y el palo ~~455r~~ y le rompió la camiseta y le hizo otros malos tratamientos y vio este testigo que así mismo el dicho Juan maltrató con palo y de moxicones a otros hermano del dicho Francisco poqeu le dijo que porqué maltrataba a su hermano y que si no llegara aquella sazón un padre que estaba allí de Santo Domingo el dicho don Juan maltratara y matara mas mal a los susodichos y ha oido este testigo decir que don Juan quiere mal al dicho Francisco porque anda con su mujera más ha de seis años y tiene el dicho don Juan en su mujer un hijo y esto pasó en presencia deste testigo y que esto que dicho tiene es la verdad...

# Reply by don Juan cacique de Fontibón
Some illegible bits of text in 456v, then letter by don Juan:

~~457r~~

> Don Juan Cacique de Fontibón, señor natural de todos aquellos indios, ante VS me querello criminalmente de unos indios mis sujetos que son uno llamado Hupaga y otro llamado Francisco Hupagachique y un hermano deste deste nombre y un Francisco Chitica y otro llamado Juan Haschique y de otro llamado Pasquepara, todos de la capitanía del capitán Alonso Chanco. 
> 
> y contando el caso digo que [...] yendo el martes a la estancia de los frailes a coger el trigo estos indios no quisieron venir conmigo sino a las cuatro de la tarde y yo como tal cacique a quien compete el remedio me llegué a donde habían venido y les reprehendí  [...] y me responderon con mucha soberbia y malas palabras y luego [...] me echaron mano y me dieron golpes y coces y mojicones [...] y me hicieron echar sangre de lo cual he estado muy malo [...] en lo cual cometieron grandísimo delito e hicieron mucho escándalo [...] grandísimo castigo porque de esto y de no castigarlos hará ==que todos pierdan respeto y no habrá quien cobre la demora y quintos reales.==

> A VS pido y suplico mande [...]

> Don Juan Cacique

