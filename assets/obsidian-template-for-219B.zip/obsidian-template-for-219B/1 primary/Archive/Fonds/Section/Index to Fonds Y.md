---
title: "Title/Reference"
start-date: YYYY-MM-DD
end-date: 
source: Zotero/Archival ref.
created: 2023-12-19 14:30
revised: 2023-12-19
---
# +Index to AGI Santafé

## 1. Consultas del Consejo, Cámara y Juntas de Indias
### Audiencia
Años 1570-1827

1, 2, 3, 4, 5, 6, 7, 11, 215, 262, 263, 264, 268, 545

### Cartagena
1575-1827

419, 420, 421, 422, 424, 425, 426, 985, 996, 997

### Santa Marta
1694-1819

496, 498, 1177, 1178

## 2. Reales Decretos, al Consejo, Cámara y Juntas de Indias
### Audiencia
1605-1759

8, 9, 10, 216, 265

## 3. Reales disposiciones (RCs, reales provisiones, cartas, instrucciones, etc.)
### Audiencia
1548-1817

12, 13, 266, 267, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 281, 282, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 541, 584

## 4. Peticiones y memoriales sueltos
1637-1699

14, 15

## 5. Cartas y expedientes, vistos en el Consejo
### SS.5.1 – De Virreyes del Nuevo Reino de Granada
1721-1759

286, 287, 288, 289, 290, 291, 292

### SS.5.2 – De Presidentes y oidores de la Audiencia
1547-1759

16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306

### SS.5.3 – De visititadores y jueces de comisión
1546-1759

56A, 56B, 57, 58, 59

### SS.5.4 – De gobernadores Cartagena, Santa Marta, Riohacha
1531-1759

37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 307, 504, 505, 506, 507, 508, 509, 510

### SS.5.5 – De corregidores y alcaldes mayores
1701-1756 d

308

### SS.5.6 – De cabildos seculares
1529-1819

#### De Santafé de Bogotá, 1539-1697
60, 61

#### Provincia de Cartagena: Cartagena, Mompox, San Sebastián de Buenavista, Santiago de Tolú. Años 1535-1758. 
62, 63, 64, 448

#### Provincia de Antioquia ( Santa Fe de Antioquia, Caramanta, Zaragoza, Cáceres y San Francisco de Guamozo) y de Mariquita (Mariquita, Ibagüe, Tocaima, Honda, Los Remedios y Victoria), 1544-1682. 
65
  
#### Provincias de Santa Marta (Santa Marta, La Ramada, Valledupar, Rio de la Hacha, Nueva Becerril de Campos, Nueva Sevilla, Nueva Palencia, Nueva Córdoba, Ontiveros, Tenerife, Nueva Valencia) y Tunja (Tunja, Pamplona y Vélez), 1529-1819 
66, 511, 1183
  
#### Provincias de Popayán (Anserma, Cali, Arma, Cartago, Buga, Toro y San sebastián de la Plata), Mérida de la Grita (Mérida, San Cristóbal, Espíritu Santo de la Grita y Barinas), Musos y Colimas (Trinidad de los Musos y Nuestra Señora de la Palma), Santa Agueda, Isla Trinidad (San José de Oruña) y San Juan de los Llanos, 1543-1676.
67
  
#### Varios, 1698-1758
309

### SS.5.7.- Del Tribunal de Cuentas de Santa Fe
1597-1759

52, 53, 54, 55, 310, 311, 312, 313, 314, 315

### SS.5.8.- De los oficiales reales de: Santa Fe, Antioquia, Cartagena y Santa Marta
1531-1759

68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 317, 318, 319, 320, 449, 450, 451, 452, 453, 454, 455, 512

### SS.5.9.- Del Juzgado de Bienes de Difuntos de Santafé
1708-1759

316

### SS.5.10.-De la Casa de la Contratación y los Consulados de Sevilla y Cádiz
1686-1756

### SS.5.11 – De Arzobispos de Santa Fe
1573-1757

226, 227, 396, 397, 398

### SS.5.12 – De obispos de Cartagena y Santa Marta
1535-1819
228, 229, 230, 488, 489, 490, 491, 518, 519, 520, 521, 522, 523, 1171, 1247, 1248

### SS.5.13 – De cabildos eclesiásticos de Santa Fé, Cartagena y Santa Marta
1543-1810
231, 232, 399, 400, 492, 493, 524, 1172

### SS.5.18 – De particulares eclesiásticos ("Cartas y expedientes de personas eclesiásticas")
1534-1759

233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 402, 403, 404, 405, 406, 407, 408, 409

### SS.5.19 – De particulares y autoridades seculares y eclesiásticas ("Cartas y expedientes", "expedientes pendientes de informe", y "expedientes resueltos")
1534-1827

187, 188, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 751, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1083A, 1084, 1085, 1086, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1201, 1202, 1203

## 6. Expedientes
### SS.6.2 – De encomiendas de indios
1551-1759

164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 347, 348, 349

## 7. Informaciones de oficio y parte de personas seculares y eclesiásticas
1527-1699

122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143