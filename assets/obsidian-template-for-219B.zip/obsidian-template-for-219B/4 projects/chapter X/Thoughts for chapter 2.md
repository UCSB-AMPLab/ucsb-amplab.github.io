Introduce [[1555 Tasa]] at beginning of -- so not just what to do with priests but how to pay them, which then better opens way for contrast with bishop as legislator. 

Visitation both opportunity for us (and them) to measure the effect of policy -- in this case tasa of 1555 and to a lesser extent synod -- but also itself effort to introduce changes or policy. 

So in this case resettlement, restitution, and TL's other initiatives, which in 1563, we can measure and judge

Conclusion: fleeting state, illusion of omnividence. 

Can end section with reflection on what Villafañe sought to introduce (sapping power of caciques, etc.), but reflect on lack of a 1566 visitation. 

Instead, Audiencia begins period of institutional unwinding, even as bishop becomes stronger. 

Setting both up for late 1570s disaster.

# Outline
  - 
  - 


# Things to cover
- [ ] A
- [ ] B
- [ ] C
- [ ] D
- [ ] E

