# Overview
From Villamarín1991, 114-115.

| Dates   | Epidemic                   | Comments |
|---------|----------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1558    | Smallpox                   | High mortality among Indians, “murió gran cantidad" (AGI, Santa Fe 188:f. 234r-235r, Oidor Grajeda to the king, October 1559). Little impact on Spaniards (Aguado [1581?] 1956-57, 1:424).                                                                                                                   |
| 1568-69 | Influenza                  | Murieron muchas gentes, especially Indians (Aguado (1581?) 1956-57, 1:426).                                                                                                                                                                                                                                  |
| 1588    | Smallpox                   | Destruyó, así naturales como españoles, más de la tercera parte de la gente (Simón [1626] 1882-92, 3:271-72).                                                                                                                                                                                                |
| 1617-18 | Measles                    | Killed more than one-fifth of the Indians. Affected other populations too, but not Spaniards bom in Spain (Simón [1626] 1882-92, 3:272).                                                                                                                                                                     |
| 1621    | Smallpox                   | Much greater impact on Indians than Spaniards (Lucena 1965:385, President Borja to the king, June 1625).                                                                                                                                                                                                     |
| 1630-33 | Typhus (tabardillo)        | "Killed about one-third of the Indians in districts of Santa Fe and Tunja. Significant mortality in all other groups as well (AGI, Santa Fe 61, Cabildo of Santa Fe to Crown, October 1633)."                                                                                                                  |
| 1651    | Smallpox                   | Primary impact on Indians (AHNC, Caciques e Indios 72:f. 916r-924v).                                                                                                                                                                                                                                         |
| 1667-68 | Smallpox                   | Heavy death toll reported in some Indian communities (AHNC, Visitas de Cundinamarca 11: f. 496r; AHNC, Miscelánea 112:r. 188r; AHNC, Caciques e Indios 57: f. 641r).                                                                                                                                         |
| 1692-93 | Measles (92) Smallpox (93) | Contributed to 30-percent decline in tributary population (Villamarin and VUlamarin 1981:80, 66-78). Strong impact (measles) on Spaniards and others also (Pacheco 1959-62,2:125).                                                                                                                           |
| 1729    | Measles                    | Most Indian communities affected (AHNC, Miscelánea 22:f. 443r, 390r-451v). Spaniards and others affected too (Vargas Jurado [1780?] 1902:13).                                                                                                                                                                |
| 1756    | Smallpox                   | Outbreak in the city and rural areas (AGI, Santa Fe 575, Viceroy Solis, December 1760).                                                                                                                                                                                                                      |
| 1781-83 | Smallpox                   | High mortality in all groups, Indian and others. In Santa Fe alone 5,000-7,000 people died (Caballero [1813] 1902:93; Posada and Ibáñez 1910:464, 469).                                                                                                                                                      |
| 1801-03 | Smallpox                   | Prevention efforts concentrated in city; no steps taken in rural Indian communities (See text and Posada and Ibáñez 1910:463-72).                                                                                                                                                                            |

## 1558 viruelas

^f2cff4

According to alcalde mayor Juan de Penagos (in [[1559-09-15 – Juan de Penagos on viruelas, Barrios, and OFM and OP - AGI SF 188, 226r-229r | 1559-09-15 letter to the king]]), the epidemic originated with enslaved Africans purchased by Juan de los Barrios brought to New Granada from Hispaniola. Estimates vary, but death rate from 15,000 (Aguado) to 40,000 (Penagos). 

AGI SF 188 is not digitised, but it is in Friede DIHC 3 as [[1559-09-15 – Juan de Penagos on viruelas, Barrios, and OFM and OP - AGI SF 188, 226r-229r]]

See Villamarín1991 at 118, and Francis2002 / Francis2005

Barrios petitioned to import four enslaved people when he was appointed bishop of the Río de la Plata, in 1548-01-26, [AGI Buenos Aires 1, libro 1, fol. 227v](http://pares.mcu.es/ParesBusquedas20/catalogo/description/236549), but I've found nothing on his importing them to Santafé.


## 1569 influenza
References:
- Dead included Villafañe (AGI SF 188 f. 728r)
- AGI Justicia 645, 186v-202r

## 1588 smallpox
References:
- AGN Testamentarias Cundinamarca 23, 826v-863r `Checking this can't actually find it`
- Many other references in 1590s visitations


---

From [[RuizRivera1975]], ~~103ff~~ 

## 1617
~~104~~ Result of famine, caused by plague of locusts, which Borja reported destroyed crops in the highlands and lowlands [[1619-06-16 – Borja to the King – AGI SF 19 n 83]]
Later identified as sarampión/measles. 
> Sobre haber dismonuido la real haciend a dice eh Tribunal de Cuentas: 
>     “uno de los cuales es haber dado los primeros meses de este año a los indios una enfermedad de sarampión muy pestilente y general, de que todvía hay residuos de tal manera que a los de la Real Corona de V. M. ha sido necesario y preciso acudirles* con comidas, regalos, me­dicinas y personas que los curasen , por ser ellos de suyo p y miserables, como se ha hecho, haciéndose el gasto de la Real Caja como cosa inexcusable y tan obligatoria (y que han hecho lo mismo los encomenderos con sus indios) de la cual enfermedad han muerto muchos, particularmente nlfios y muchachos, que a su tiempo harán gran falta ; y demás de lo que en esto se ha gastado, no se ha podido cobrar de los indios enteramente lo que debían de la paga de Navidad pasad a de demoras y requinitos". 
> Tribunal de Cuentas a SM, Santafé, 13 de Junio de 1618. AGI SF 52 , 132.

## 1633 - Tabardillo (typhus)
~~105~~ Killed Almansa, so ecclesiastical historians make a big fuss and claim it was a result of authorities persecuting him. (e.g. Groot, vol I, 453)

Almansa had been banished to Facatativá, where the epidemic began.

But no real evidence, save for Simón

## 1644 – 
Famine again, especially in lowlands.