1519 - Enciso
1526 - Oviedo (Natural historia)
1539 - San Martín & Lebrija
1539-48 - Oviedo
1545-50 (approx.) - Anon. Relación SM y NR
1545-1550 (approx.) - Epítome
1553 (&1871) - Cieza
1570s (pub. 1582) - Aguado OFM
1589 - Castellanos
1619 - Remesal OP
1627 - Simón OFM
1636-38 - Freyle
1681 - Meléndez OP
1688 - Piedrahita
1691-1696 - Zamora OP