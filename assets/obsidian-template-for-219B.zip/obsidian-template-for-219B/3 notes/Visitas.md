From [[Colmenares1976]] (84), [[EugenioMartinez1977]] (125), and AGN.

| Dates | Tunja | Santafé |
| ---- | ---- | ---- |
| 1546 | M. D. Armendáriz | M. D. Armendáriz |
| 1551 | Ruiz de Orejuela |  |
|  |  | B. Maldonado/ P. Escudero Herrezuelo |
| 1560 | Tomás López | Tomás López |
| 1562-4 | Angulo de Castejón |  |
| 1563 |  | Villafañe |
| 1570-2 | Cepeda |  |
| 1579 | Monzón | Monzón |
| 1583-4 | Prieto de Orellana | Prieto de Orellana |
| 1590 |  | Ferráez de Porras |
| 1593-1595 |  | Miguel de Ibarra |
| 1595-1596 | Egas de Guzmán |  |
| 1599-1602 | Luis Enríquez |  |
| 1603? | Gómez de Mena |  |
| 1617 | Lesmes de Espinosa Saravia (focus Vélez) |  |
| 1635 | Juan de Valcárcel |  |
| 1638-1639 |  | Carvajal |
**Civiles:**
- [[Visitas Tomás López (1560)]]
- [[Visitas Villafañe (1563-5)]]
- [[Visitas Cepeda (1571-72)]]
- [[Visitas Ibarra (1593-1595)]]
- [[Visitas Egas de Guzmán (1595-1596)]]
- [[Visitas Enríquez (1599-1602)]]
- [[Visita Lesmes de Espinosa (1617)]]
- [[Visitas Valcárcel (1635-36)]]
- [[Visitas Carvajal (1638-39)]]

**Eclesiásticas:**
- [[Visitas Arias de Ugarte (1619-24)]]
