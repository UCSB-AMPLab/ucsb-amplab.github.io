#place/town 

1560 – Part of encomienda of María de Sotelo