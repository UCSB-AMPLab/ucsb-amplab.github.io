---
aliases: [Hontibón, Fontibon, Hontibon]
location: [4.6732943,-74.1447464]
---
#place 
#place/town/fontibon 