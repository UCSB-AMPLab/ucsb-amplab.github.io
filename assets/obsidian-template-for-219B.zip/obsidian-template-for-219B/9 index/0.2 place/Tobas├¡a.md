#place/town 

Near modern-day Floresta, Boyacá.

