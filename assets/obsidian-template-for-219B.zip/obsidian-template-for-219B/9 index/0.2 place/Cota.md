---
location: [4.795346536669572,-74.0930880547967]
---

[[1604-12-09 – Visita a Cota, necesita nueva Iglesia – AGN V_Cun 11, ff. 700r-705r]]

#place/town 
