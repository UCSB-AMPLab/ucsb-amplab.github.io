#place/town 
1560, encomienda Antón de Esquivel