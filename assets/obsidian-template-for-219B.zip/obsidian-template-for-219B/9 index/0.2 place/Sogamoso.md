#place/town 

Royal encomienda by 1560, but from when?

Official history of now diocese of Duitama-Sogamoso says OFM arrived in 1555

In PARES, I found two things concerning Sogamoso from around the time of the 1560 visitation:
- 1556 –  Real Provisión ejecutoria en el pleito entre Cristóbal de San Miguel, con el fiscal Villalobos y con el capitán Gonzalo Suárez, sobre los indios del cacique Sogamoso y sus tributos – PATRONATO,283,N.2,R.140 http://pares.mcu.es/ParesBusquedas20/catalogo/description/130346
- 1563 - Diligencias sobre bienes de difuntos: Francisco Rodríguez, maestro de molinos, natural de Santa Olalla, difunto en Sogamoso – CONTRATACION,201,N.2,R.5  http://pares.mcu.es:80/ParesBusquedas20/catalogo/description/70585