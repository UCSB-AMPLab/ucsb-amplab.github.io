#person 

Regidor cabildo SF, who is sent as procurator to court in 1554.

Also escribano, associated with the libro de acuerdo for the 1550s.

Imprisoned for some time, as reported in [[1554-03-01 – Carta de Luis Lanchero al Rey informando largamente sobre la situación en el Nuevo Reino Santafé – AGI SF 188, fol. 51]]
