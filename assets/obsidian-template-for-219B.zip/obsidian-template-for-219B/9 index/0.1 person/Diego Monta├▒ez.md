#person 

The awful encomendero of Tota and Guáquira, of course.