---
full-name: "Agustín de Sotomayor"
first-name: "Agustín de"
surname: "Sotomayor"
affiliation: "OSA"
date-created: 2022-08-16
---
#person/priest

# Agustín de Sotomayor

Notes on Agustín de Sotomayor OSA

# Appearances in AGN CO catalogue:
- 1609: Sotomayor Agustín de: religioso agustino, su nombramiento de cura de Guateque. [AGN CO 28 d 9](http://consulta.archivogeneral.gov.co/ConsultaWeb/descripcion.jsp?id=3009958)