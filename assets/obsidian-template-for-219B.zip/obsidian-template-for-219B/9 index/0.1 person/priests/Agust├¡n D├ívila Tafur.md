---
full-name: "Agustín Dávila Tafur"
first-name: "Agustín"
surname: "Dávila Tafur"
affiliation: "n/a"
date-created: 2022-08-16
---
#person/priest

# Agustín Dávila Tafur

Notes on Agustín Dávila Tafur

# Appearances in AGN CO catalogue:
- 1617: Dávila Tafur Agustín: electo sacristán de la iglesia de Mariquita. [AGN CO 28 d 139](http://consulta.archivogeneral.gov.co/ConsultaWeb/descripcion.jsp?id=3010325)