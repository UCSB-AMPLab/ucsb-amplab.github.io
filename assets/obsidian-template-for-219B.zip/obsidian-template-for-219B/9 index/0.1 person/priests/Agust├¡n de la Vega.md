---
full-name: "Agustín de la Vega"
first-name: "Agustín de la"
surname: "Vega"
affiliation: "OP"
date-created: 2022-08-16
---
#person/priest

# Agustín de la Vega

Notes on Agustín de la Vega OP

# Appearances in AGN CO catalogue:
- 1621: Vega Agustín de la, O.P.: electo cura de Boyacá. [AGN CO 28 d 177](http://consulta.archivogeneral.gov.co/ConsultaWeb/descripcion.jsp?id=3010428)