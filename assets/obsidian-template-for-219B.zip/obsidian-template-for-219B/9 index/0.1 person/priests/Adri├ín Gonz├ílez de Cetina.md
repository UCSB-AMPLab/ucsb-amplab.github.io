---
full-name: "Adrián González de Cetina"
first-name: "Adrián"
surname: "González de Cetina"
affiliation: "n/a"
date-created: 2022-08-16
---
#person/priest

# Adrián González de Cetina

Notes on Adrián González de Cetina

# Appearances in AGN CO catalogue:
- 1664: Adrián González de Cetina, dimite curato de Coloya.. [AGN CO 4 d 24](http://consulta.archivogeneral.gov.co/ConsultaWeb/descripcion.jsp?id=3005588)