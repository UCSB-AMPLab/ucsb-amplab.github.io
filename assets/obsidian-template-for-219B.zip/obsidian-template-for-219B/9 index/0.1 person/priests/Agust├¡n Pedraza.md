---
full-name: "Agustín Pedraza"
first-name: "Agustín"
surname: "Pedraza"
affiliation: "OP"
date-created: 2022-08-16
---
#person/priest

# Agustín Pedraza

Notes on Agustín Pedraza OP

# Appearances in AGN CO catalogue:
- 1618: Pedraza Agustín O.P.: electo cura de Sopó. [AGN CO 28 d 169](http://consulta.archivogeneral.gov.co/ConsultaWeb/descripcion.jsp?id=3010409)
- 1624: Pedraza Agustín O.P.: electo cura de Guatavita. [AGN CO 28 d 244](http://consulta.archivogeneral.gov.co/ConsultaWeb/descripcion.jsp?id=3010621)