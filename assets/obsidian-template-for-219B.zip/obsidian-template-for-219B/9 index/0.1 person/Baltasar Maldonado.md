#person 
Baltasar Maldonado (c. 1510-1558), served under Gonzalo Jiménez and later Hernán Pérez de Quesada. 

In 1560, late encomendero of Duitama.