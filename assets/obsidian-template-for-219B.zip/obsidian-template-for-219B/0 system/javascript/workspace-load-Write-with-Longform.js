module.exports = async () =>
{
	window.open("obsidian://advanced-uri?workspace=Write-with-Longform");
}