module.exports = async () =>
{
	window.open("obsidian://advanced-uri?workspace=Work-with-notes");
}