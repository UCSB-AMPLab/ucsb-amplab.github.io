
```dataview
TASK
FROM -"07 writing"
SORT file.mtime DESC
```
%%This is a task list created with Dataview. Hover over the task list to see the button in the top right corner. Click on the button to see the Dataview quiery. This query pulls all tasks from the vault, except Kanban cards from the "07 writing" folder, used for outlining.%%