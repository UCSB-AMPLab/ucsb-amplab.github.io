---
title: "Title/Reference"
start-date: YYYY-MM-DD
end-date: 
source: Zotero/Archival ref.
created: <% tp.file.creation_date() %>
revised: <% tp.file.last_modified_date("YYYY-MM-DD") %>
---

# YYYY-MM-DD – Short title – Archival ref.

## Notes/Comments



## Section
~~1r~~

