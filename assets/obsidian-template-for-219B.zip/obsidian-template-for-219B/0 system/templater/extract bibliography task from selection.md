<%*
tp.file.create_new('#task \n'+tp.user.projecttag(tp)+'\n\n'+ tp.file.selection(), "new task");
-%>