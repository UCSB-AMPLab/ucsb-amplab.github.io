# Hallo!

This is a starter Obsidian vault for archival research. It contains a folder structure, sample files, formatting conventions, templates, and plugins designed to help you build a sustainable, searchable, plain-text research database.

## Resources

- [Ango, "File over app"](https://stephango.com/file-over-app) — why plain text and local files matter
- [Simpkin, "Getting Started with Markdown"](https://programminghistorian.org/en/lessons/getting-started-with-markdown) — a tutorial on the formatting language used in this vault

## Vault structure

The vault comes with sample files from my own research to show you what each folder is for and how the system works in practice. These are examples — delete them whenever you're ready and replace them with your own materials.

```
obsidian-template-for-219B/
├── 0 system/          Configuration, templates, and scripts (no need to touch)
│   ├── attachments/   Images and other files
│   ├── dataview/      Pre-built search and query views
│   ├── templater/     Templates for new notes
│   └── zotero/        Zotero integration template
│
├── 1 primary/         Primary source transcriptions
│   └── Archive/       Organised to mirror the structure of the archive
│       └── Fonds/
│           └── Section/
│               ├── Index to Fonds Y.md          ← example index
│               └── Volume or box/
│                   ├── +Index of Box X.md        ← example box index
│                   └── 1594-1596 – Juan... .md   ← example transcription
│
├── 2 secondary/       Notes on secondary literature
│   └── Kaser2004IusGentium.md                    ← example reading notes
│
├── 3 notes/           Synthetic notes — where the thinking happens
│   ├── + diary/       Research diary (daily log of work)
│   ├── 1555 Tasa.md                              ← example synthetic notes
│   ├── Chroniclers.md
│   ├── Epidemics.md
│   └── Visitas.md
│
├── 4 projects/        Where notes come together into outputs
│   └── chapter X/
│       └── Thoughts for chapter 2.md             ← example project file
│
└── 9 index/           Index of recurring entities
    ├── 0.1 person/    People                      ← example entries
    └── 0.2 place/     Places                      ← example entries
```

## What goes where

### `1 primary/` — Primary sources
This is where you put transcriptions of archival documents. The folder structure mirrors the archive itself: archive > fonds > section > volume or box (or however your archive is organised -- I also have a folder for published sources). Each document gets its own file. Index files (prefixed with `+`) also serve as to-do lists for working through a box or folder.

### `2 secondary/` — Secondary literature
One file per book or article. Include bibliographic details at the top and your reading notes below. If you use Zotero, there is a template in `0 system/zotero/` for importing notes.

### `3 notes/` — Synthetic notes
As you read primary and secondary sources, you will begin to notice themes, connections, and patterns. This is where you write them up — one file per topic, pulling together observations from across your sources. Obsidian's linking is useful: you can link directly to (or even embed) transcriptions, reading notes, or other synthetic notes using `[[wikilinks]]`.

The `+ diary` subfolder is a good place to keep a daily log of your research — what you read, what you found, what you're thinking about. This helps with periods of "I don't know where my time is going" panic.

### `4 projects/` — Projects
This is where notes begin to come together into specific things — a chapter, an article, a talk, a seminar paper. A project file typically draws on synthetic notes and primary sources to build an argument or outline. See the included example for the very beginning of thinking about a book chapter.

### `9 index/` — Index of entities
A place to keep track of recurring characters, places, institutions, or anything else you need to cross-reference. One file per entity. You can organise them into subfolders (people, places, etc.) as you see fit, and add new categories as they become necessary.

### Adding your own folders
This structure is a starting point. You may add others as they become necessary or as you find a workflow that works for you.

## Formatting conventions

The vault uses a custom CSS snippet that gives semantic meaning to standard Markdown formatting. This makes transcriptions visually distinct from your own notes.

| What you type          | What it means                                |
| ---------------------- | -------------------------------------------- |
| Normal text            | Your thoughts, paraphrasing, analysis        |
| `> quoted text`        | Verbatim transcription of a source           |
| `==highlighted text==` | Important passages                           |
| `%% comment %%`        | Editorial comments and questions to yourself |
| `~~1r~~`, `~~362v~~`   | Folio or page references in transcriptions   |
| `[[note name]]`        | Link to another note in the vault            |
| `![[note name]]`       | Embed another note's content inline          |

### Keyboard shortcuts

`cmd+8` or `F8`: Toggle ==highlight==                              
`cmd+9` or `F9`: Insert %% comment %%                              
`cmd+0` or `F10`: Insert ~~strikethrough~~ (for pagination markers) 

### Headings

Use headings (`# H1` through `###### H6`) to structure your notes. In transcription files, headings are useful for marking sections, witnesses, or distinct documents within a single file.

## Customising the appearance

The CSS snippet that controls the vault's appearance is in the hidden folder `.obsidian/snippets/` inside the vault.

You can edit the file `cobo-typography-for-219b-vault.css` to change colours, fonts, or any of the conventions above.

Good luck!
— J.