
Book concerned with the expression "*ius gentium*" in Roman Law in Antiquity (and only then).

Idea here that there are two main thrusts. One is the *ius gentium* that had a an "international-public" character, which came to be developed in key ways after Antiquity, but was only rarely considered Roman jurisprudential literature. And a second, "juridico-privado" *ius gentium* (so-called by Kaser, a posteriori), which was based on the doctrine of natural law that came out of Greek philosophy as assumed into Roman jurisprudence. (204-5)

In this second sense, the decisive characteristics of humanity are ultimately common to all men, regardless of race or nationality. From this are also derived a number of juridical ideas and several institutions and norms of Law which serve to give a concordant shape to all men. 

From these perceptions, Roman juridical creation produced later a Law — principally a private law — "of all peoples" (*ius gentium*) that was binding on all free men. As a result, this was also binding on non-romans, and in turn produced effects in the *ius civile Romanorum* that complemented it and completed it.

--- 

### 24. Tricotomía ius civile, ius gentium, ius naturale

Justinian took this form a passage of Ulpian and placed it in the initial titles of the Institutes and Digest which are concerned with the fundamentals of law.

The text that begins *Ulpiani institutionum libri duo*, starts with an introductory chapter that seeks to familiarise beginners in the study of the law with some general concepts, and like the rest of the work needs to be judged as a work of isagogics.

~~83~~ Text begins with some preliminary considerations about the content and purpose of *ius* and about *iustitia* which could have come to the author from Greek models through the intermediation of Cicero. 

This is followed by the "division" of *ius* into *publicum* and *privatum*, and then the subdivision of *privatum* into three: the "natural juridical precepts", those "of (all) men", and those "of (and for) the citizens":

```
D. 1.1.1.2 ... privatum ius triperitum est: collectum etenim est ex naturalibus praeceptis aut gentium aut civilibus
```
What is interesting here is that only the *ius privatum* appears to be divided into those three categories, keeping the *ius gentium* separate from the *ius publicum*. In this way, the concept of *ius gentium* as "derecho de gentes" is therefore understood here as a separate concept. `cf. Grotius et al later`

Same in Institutes, with some minor differences:
```
I. 1.1.4. i.f.; ... de iure privato, quod est tripertitum: collectum est enim ex naturalibus praeceptis aut gentium aut civilibus.
```

The tripartition of D. 1.1.1.2 i.f. is explained further in §§3 and 4 and in eod. 6 pr.:
~~84~~

```

D. 1.1.1.3: Ius naturale est, quod natura omnia animalia docuit: nam ius istud non humani generis proprium, sed omnium animalium, quae in terra, quae in mari nascuntur, avium quoque commune est. hinc descendit maris atque feminae coniunctio, quam nos matrimonium appellamus, hinc liberorum procreatio, hinc educatio; videmus etenim cetera quoque animalia, fera etiam istius iuris peritia censeri.

D. 1.1.1.4: Ius gentium est, quo gentes humanae utuntur quod a naturali recedere facile intellegere licet, quia illud omniubs animalibus, hoc solis hominibus inter se commune sit.

D. 1.1.1.6 pr.: Ius civile est, quod neque in totum a naturali vel gentium recedir nec per omnia ei servit: itaque cum aliquid addimus vel detrahimus iuri communi, ius proprium, id est civile efficimus.
```
The three paragraphs presumably directly followed the text from Ulpian.

~~85~~ According to the fr. 1.4, the *ius gentium* sits behind the *ius naturale*, in the sense that it is not valid for all creatures, including animals, but only among humans. The *ius civile*, in contrast, is a Ius that according to fr. 6 pr., no "queda por detrás" of the *naturale vel gentium (ius)*. ...

---

Part II of the book ~~95ff~~ concerned with the 'objects' of the *ius gentium*, in three parts: rights of people, family, and succession; derechos reales; and derecho de obligaciones.

One key case is the contradiction inherent in the question of slavery, where ~~96~~ *ius gentium* and *natura* follow different paths. Even the jurists hold the fact that all men are born free as an uncontrovertible fact. But, slavery is also known among every people (known by the Romans), which makes it *iuris gentium*. And yet it is also contrary to nature, and therefore cannot be *ius naturale*.

So interesting mental gymnastics.